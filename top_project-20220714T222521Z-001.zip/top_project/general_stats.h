//#pragma message "compiling: general_stats.h "

#include "error_handler.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

float general_cpu_usage();		// calcola la % totale di utilizzo della CPU
float general_memory_usage();	// calcola la % totale di utilizzo della memoria
