#include "general_stats.h"
#include "process_stats.h"


int main(){
	
	while(1){
		sleep(1);
		
		printf("\ncpu_usage:\t %f %\n", general_cpu_usage() );	// rivedi i valori che restituisce
		printf("memory_usage:\t %f %\n", general_memory_usage() );
		
		printf("proc_cpu_usage:\t %f %\n", process_cpu_usage("/proc/843/stat") );
		printf("proc_memory usage:\t %f %\n", process_memory_usage("/proc/843/status") );	// ok, andata
		sleep(3);
	}
}
