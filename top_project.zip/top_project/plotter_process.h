#include <dirent.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "error_handler.h"
#include "process_stats.h"

#define FILE_STAT 	"/stat"
#define FILE_STATUS "/status"

char* get_process();


